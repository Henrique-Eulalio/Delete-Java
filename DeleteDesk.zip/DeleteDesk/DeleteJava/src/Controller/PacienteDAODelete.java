package Controller;

import Model.PacienteDelete;
import com.mysql.jdbc.Statement;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class PacienteDAODelete {
    private Connection con;
    private PreparedStatement cmd;

    public PacienteDAODelete(){
        this.con = Conexao.Conectar();
    }

    public int deletar(PacienteDelete p){
        try {
            String sql = "delete from paciente where id = ?";
            
            cmd = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            cmd.setInt(1, p.getId());
            cmd.execute();
            JOptionPane.showMessageDialog(null, "Excluido com sucesso");
        } catch (HeadlessException | SQLException e) {
            System.out.println("Erro: " + e.getMessage());
            return -1;
        }
        finally{
            Conexao.Desconectar(con);
        }
        return 0;
    }
     public List<PacienteDelete> listar(){
        try {
            String sql = "select * from paciente order by id";
            cmd = con.prepareStatement(sql);
            ResultSet rs = cmd.executeQuery();
            
            List<PacienteDelete> lista = new ArrayList<>();
            while(rs.next()){
                PacienteDelete p = new PacienteDelete();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setPeso(rs.getFloat("peso"));
                p.setAltura(rs.getFloat("altura"));
                
                lista.add(p); 
        } 
            return lista;
       }
        catch (Exception e) {
                System.out.println("Erro: " + e.getMessage());
                return null;
                }
        finally{
            Conexao.Desconectar(con);
        }
        }
}

